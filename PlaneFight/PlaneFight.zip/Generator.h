#pragma once
#include "EnemyGenerator.h"

namespace Generator {
	EnemyGenerator* level(int n);
}    // namespace Generator
